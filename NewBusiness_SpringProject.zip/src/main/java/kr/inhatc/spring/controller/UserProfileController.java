package kr.inhatc.spring.controller;

import java.util.*;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kr.inhatc.spring.model.UserProfile;

@RestController
public class UserProfileController{
	
	//Map-userprofile을 담는 Map생성
	private Map<String, UserProfile> userMap;
	
	@PostConstruct //postconstruct는 userprofileController만들고 직후에 호출
	public void init() {
		userMap=new HashMap<String, UserProfile>();
		userMap.put("1", new UserProfile("1","홍길동","1234-5678","대구시 태전동"));
		userMap.put("2", new UserProfile("2","김민정","1235-5678","김포시 태전동"));
		userMap.put("3", new UserProfile("3","양다운","1236-5678","서울시 태전동"));
		//userMap에 정보삽입
	}
	
	
	@GetMapping("/user/{id}")//어노테이션 GetMapping은 데이터를 조회할 경우에 쓰는 어노테이션이다.
	public UserProfile getUserProfile(@PathVariable("id")String id) {
		return userMap.get(id);
	}
	@GetMapping("/user/all")
	public List<UserProfile> getUserProfileList() {
		return new ArrayList<UserProfile>(userMap.values());
	}
	@PutMapping("/user/{id}")//"추가"할 아이디와 이름, 전화번호, 주소를 파라미터로 전달받는다.
	public void putUserProfile(@PathVariable("id") String id, @RequestParam("name") String name, @RequestParam("phone") String phone,@RequestParam("address") String address) {
		//userProfile객체를 생성하여 
		UserProfile userprofile=new UserProfile(id,name,phone,address);
		userMap.put(id, userprofile);
	}
	@PostMapping("/user/{id}")//"수정"할 아이디와 이름, 전화번호, 주소를 파라미터로 전달받는다.
	public void postUserProfile(@PathVariable("id") String id, @RequestParam("name") String name, @RequestParam("phone") String phone,@RequestParam("address") String address) {
		UserProfile userprofile=userMap.get(id);
		userprofile.setName(name);
		userprofile.setPhone(phone);
		userprofile.setAddress(address);
	}
	@DeleteMapping("user/{id}")
	public void DeleteUserProfile(@PathVariable("id") String id) {
		userMap.remove(id);
	}
	
}
