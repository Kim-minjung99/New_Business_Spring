package kr.inhatc.spring.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BootController{
	@RequestMapping("/")
	public String loginView() {
		return "login";
	}
	@RequestMapping("/index")
	public String MainView() {
		return "index";
	}
}